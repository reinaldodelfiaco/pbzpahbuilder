# PBZPA/PBZPH Builder

PBZPA/PBZPH Builder is a QGIS plugin for Brazilian aerodrome and heliport protection planning workflows.

It generates PBZPA obstacle limitation surfaces from runway threshold data, supports inactive runway ends, records SSPV sector selection, creates OPEA review layers, runs preliminary OPEA checks, and exports KML/KMZ, DXF, optional DWG, SYSAGA support information sheets and elevation tables.

## Status

Version: **0.3.1**

PBZPA generation is enabled. PBZPH is available as a project type selector, but PBZPH drawing and support-sheet generation are blocked until the authenticated SYSAGA Annex B field structure is confirmed.

## Optional Dependencies

- `ezdxf` for DXF export.
- `onnxruntime` for machine-learning OPEA suggestions.
- ODA File Converter for DWG conversion.

Install Python dependencies in the QGIS Python environment, for example from OSGeo4W Shell on Windows:

```powershell
python -m pip install ezdxf onnxruntime
```

## Documentation

Full documentation is maintained in the public source repository:

https://github.com/reinaldodelfiaco/pbzpahbuilder

English manual:

https://github.com/reinaldodelfiaco/pbzpahbuilder/blob/main/docs/user_manual.md

Portuguese manual:

https://github.com/reinaldodelfiaco/pbzpahbuilder/blob/main/docs/manual_usuario.md

## License

GPL-3.0-or-later. See `LICENSE`.
